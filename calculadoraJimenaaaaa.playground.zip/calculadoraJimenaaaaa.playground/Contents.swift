func suma (numero1: Double, numero2: Double) -> Double {
    
    return numero1 + numero2
}

func resta (numero1: Double, numero2: Double) -> Double {
    
    
    return numero1 - numero2
}

func multiplicacion (numero1: Double, numero2: Double) -> Double {
    
    return numero1 * numero2
}

func division (numero1: Double, numero2: Double) -> Double {
        
        return numero1 / numero2
}

func calculadora(opcion: Int, numero1: Double, numero2: Double){
    
    switch opcion {
    case 1:
        
        print("El resultado de la suma es (suma (numero1: numero1, numero2: numero2))")
    case 2:
        
        print("El resultado de la resta es (suma (numero1: numero1, numero2: numero2))")
    case 3:
        
        print("El resultado de la multiplicacion es (suma (numero1: numero1, numero2: numero2))")
    case 4:
        
        if numero2 == 0 {
            print("No es posible dividir entre 0, ingrese un numero mayor")
        } else {
            
            print("El resultado de la division es (suma (numero1: numero1, numero2: numero2))")
        }
    default:
        
        print("Ingrese una opcion del 1 al 4")
    }
}

func menu(){
    
    var operacion = 0
    var numero1: Double
    var numero2: Double
    
    print("Ingresa la opcion de la operacion que deseas realizar")
    print("1. Suma 2.Resta 3.Multiplicacion 4. Division")
    operacion = Int(readLine()!)!
    if operacion < 5{
        print ("Ingresa el primer numero: ")
        numero1 = Double(readLine()!)!
        print ("Ingresa el segundo numero: ")
        numero2 = Double(readLine()!)!
        
        calculadora(opcion: operacion, numero1: numero1, numero2: numero2)
    }
    return
}

